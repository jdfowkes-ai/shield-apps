"""Android TV shortcuts and an artwork-enabled Kodi widget directory."""
import json
import os
import sys
import re
from urllib.parse import parse_qs, urlencode
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
with open(os.path.join(ROOT, 'resources', 'apps.json'), encoding='utf-8') as source:
    APPS = json.load(source)


def main():
    handle = int(sys.argv[1])
    params = parse_qs(sys.argv[2].lstrip('?'))
    action = params.get('action', ['list'])[0]
    if action == 'launch':
        app_id = params.get('id', [''])[0]
        app = next((entry for entry in APPS if entry['id'] == app_id), None)
        if app is None:
            xbmcgui.Dialog().notification('Shield Apps', 'Unknown app shortcut', xbmcgui.NOTIFICATION_ERROR)
            return
        if not xbmc.getCondVisibility('System.Platform.Android'):
            xbmcgui.Dialog().ok('Shield Apps', 'These shortcuts need Kodi on Android TV or NVIDIA Shield.')
            return
        package = (ADDON.getSetting('hbo_package') or app['package']) if app_id == 'hbo-max' else app['package']
        if not re.fullmatch(r'[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+', package):
            xbmcgui.Dialog().ok('Shield Apps', 'Invalid Android package name in settings.')
            return
        xbmc.executebuiltin('StartAndroidActivity({})'.format(package))
        return
    xbmcplugin.setPluginCategory(handle, 'APPS')
    xbmcplugin.setContent(handle, 'files')
    for app in APPS:
        art = os.path.join(ROOT, 'resources', 'art', app['id'])
        icon = os.path.join(art, 'icon-v121.png')
        item = xbmcgui.ListItem(label=app['label'])
        landscape = os.path.join(art, 'landscape-v121.png')
        thumb = landscape if ADDON.getSetting('tile_shape') == 'Rectangle' else icon
        clearlogo = os.path.join(art, 'clearlogo-v120.png')
        item.setArt({'icon': icon, 'thumb': thumb, 'poster': icon, 'landscape': landscape,
                     'fanart': os.path.join(art, 'fanart-clean-v120.jpg'),
                     'clearlogo': clearlogo if os.path.isfile(clearlogo) else ''})
        item.setProperty('IsPlayable', 'false')
        url = sys.argv[0] + '?' + urlencode({'action': 'launch', 'id': app['id']})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == '__main__':
    main()
