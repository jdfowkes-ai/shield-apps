1.2.1
- Solid service-coloured backgrounds on all square and rectangular app tiles.
- Transparent title clearlogos and logo-free fanart retained.
- Updated tile filenames to refresh cached artwork.
