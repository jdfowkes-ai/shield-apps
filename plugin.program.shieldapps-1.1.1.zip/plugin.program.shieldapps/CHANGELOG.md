1.1.1
- BBC iPlayer fanart without embedded branding.
- Separate transparent BBC iPlayer clearlogo supplied to the skin.
- Existing app tiles and launch actions retained.
